 describe("MathUtils",function()
  {
  var calc;
  beforeEach(function()
  {
  calc= new MathUtils();
  spyOn(calc,'sum');//this is used to check that the function is called or not.......
  });
  
  describe("we are testing basic javascript function",function()
  {
  
  it("to check if the function is called or not",function()
  {
  calc.sum(12,13);
  expect(calc.sum).toHaveBeenCalled();
  expect(calc.sum).toHaveBeenCalledWith(12,13);
  })
  
  })
})