describe("MathUtils", function() {
    var calc;
 
    //This will be called before running each spec
    beforeEach(function() {
        calc = new MathUtils();
    });
 
    describe("when calc is used to peform basic math operations", function(){
         
        //Spec for sum operation
        it("should be able to calculate sum of 3 and 5", function() {
            expect(calc.sum(3,5)).toEqual(8);
        });

        //Spec for subtraction operation
        it("should be able to calculate substract of 3 and 5", function() {
            expect(calc.substract(13,5)).toEqual(8);
        });

 
        //Spec for multiply operation
        it("should be able to multiply 10 and 40", function() {
            expect(calc.multiply(10, 40)).toEqual(400);
        });
 
        //Spec for division operation
        it("should be able to calculate division of 6 and 2", function() {
            expect(calc.divide(6,2)).toEqual(3);
        });

         //Spec for average operation
         it("should be able to calculate average of 6 and 2", function() {
            expect(calc.average(6,2)).toEqual(4);
        });
         //Spec for average operation
         it("should be able to calculate average of 6 and 2 and should be less than 5", function() {
            expect(calc.average(6,2)).toBeLessThan(5);
        });

         //Spec for average operation
         it("should be able to calculate average of 6 and 2 and should be greater than 3", function() {
            expect(calc.average(6,2)).toBeGreaterThan(3);
        });

         //Spec for factorial operation
        it("should be able to calculate factorial of a given number", function() {
        expect(calc.factorial(4)).toBeGreaterThan(20);
        });

        //Spec for factorial operation
        it("should be able to calculate factorial of a given number", function() {
            expect(calc.factorial(-4)).toThrowError(Error);
            });
         
    });
});