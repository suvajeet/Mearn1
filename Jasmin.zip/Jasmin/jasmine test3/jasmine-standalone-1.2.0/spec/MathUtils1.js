describe("MathUtils", function() {
    var calc;
 
    //This will be called before running each spec
    beforeEach(function() {
        calc = new MathUtils();
        spyOn(calc,'sum')  // to check when a function is called .It return true when the function is called .
    });
 
    describe("when calc is used to peform basic math operations", function(){
         
        //Spec for sum operation
        it("should be able to calculate sum of 3 and 5", function() {
            calc.sum(13,12);

            
            expect(calc.sum).toHaveBeenCalled(); //the function sum is called or not

            expect(calc.sum).toHaveBeenCalledWith(13,12); //the function is called or not with parameter


        });
      
    });
});
