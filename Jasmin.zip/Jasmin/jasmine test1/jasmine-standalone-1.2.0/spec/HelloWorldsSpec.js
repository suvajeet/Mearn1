describe("MathUtils",function(){
    var calc;
  beforeEach(function(){
    calc= new MathUtils();
  });
  describe("we are testing basic javascript function",function(){
      it("should be able to calculate sum of any 2 numbers",function(){
          expect(calc.sum(4,5)).toEqual(9);
      })

      it("should be able to calculate sub of any 2 numbers",function(){
        expect(calc.sub(5,4)).toEqual(1);
      })
      it("should be able to calculate mul of any 2 numbers",function(){
        expect(calc.mul(5,4)).toEqual(20);
      })
      it("should be able to calculate div of any 2 numbers",function(){
        expect(calc.div(15,3)).toEqual(5);
      })
      it("should be able to calculate avg of any 2 nos",function()
      {
      expect(calc.avg(4,6)).toBeGreaterThan(4);
      })
      
      it("should be able to calculate avg of any 2 nos",function()
      {
      expect(calc.avg(4,6)).toBeCloseTo(5);
      })
      it("should not be able to calculate factorial of a given nagative number",function()
      {
      expect(calc.factorial(-4)).toEqual("There is no factorial for negative numbers");
      })
      
      it("should be able to calculate factorial of a given number",function()
      {
      expect(calc.factorial(4)).toBeGreaterThan(23);
      })

      it("should be able to display hello + name",function()
      {
      expect(calc.name("suvajeet")).toMatch("hello suvajeet");
      })
      
      it("should be able to display hello + name if name is defined",function()
      {
      var name="suvajeet";
      expect(calc.name(name)).toBeDefined();
      })
      
      it("should be unable to display hello + name if name is undefined",function()
      {
      var name;
      expect(calc.name1(name)).toBeUndefined();
      })
  })
})