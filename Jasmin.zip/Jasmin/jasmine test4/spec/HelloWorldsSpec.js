describe("Nested describe Example", function()
{
var calc;
beforeEach(function() {
calc = new MathUtils();
console.log("before the function execution level 1");
});

describe("Mytest Level 2", function()
{
beforeEach(function() {
console.log("before the function execution Level 2");
});

describe("Mytest Level 3", function()
{
beforeEach(function() {
console.log("before the function execution Level 3");
});

it("it is a test of the function",function()
{
console.log("this is a test of the function level 3");
expect(calc.sum(4,5)).toBe(9);
});

afterEach(function()
{
console.log("the result is 9 for level 3");
});
it("it is a test of the function level 3 after Each",function()
{
console.log("this is a test of the function level afterEach");
expect(calc.sum(4,5)).toEqual(9);
});
});

afterEach(function()
{
console.log("after level 2");
});
});

afterEach(function()
{
console.log("after level 1");
});
});