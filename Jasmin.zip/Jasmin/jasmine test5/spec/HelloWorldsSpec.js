describe("Calculator",function()
{
//test case:1
it("should retain the current value",function()
{
expect(Calculator.currentVal).toBeDefined();
expect(Calculator.currentVal).toEqual(0);
});

//test case:2
it("should add the number",function()
{
expect(Calculator.add(5)).toEqual(5);
});

//test case:3
it("should add any number and the current value will be changed",function()
{
expect(Calculator.addAny(4)).toEqual(9);
});
});