export interface Workout {
    title: string;
    note: string;
    calories: number;
    category: string;
}