import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { AlertService } from '../alert/alert.service';
import {BrowserModule} from '@angular/platform-browser';
import { AppModule } from '../app.module';
import {Observable} from "rxjs/Observable";
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import {RouterModule,Router,Routes,ActivatedRoute} from "@angular/router";

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {

  categories: Array<any>;
  category_name: string;
  invalid: boolean;
    
  //constructor(private httpService: HttpService, private alertService: AlertService) { 
    constructor(
      formBuilder: FormBuilder,
      private __HttpService: HttpService,
      private router: Router,
      private route: ActivatedRoute,
      private alert:AlertService
    ) {
    this.getCategories();
  }

  addCategory(): void {
    const newCategory ={
      category_name: this.category_name}

    /*if(this.newCategory && this.newCategory.length > 0) {
      const status =
      this.httpService.saveCategory(this.newCategory);
      if(status) {
        this.alertService.addAlert('Category updated successfully..!!', 'success');
        this.getCategories();
        this.newCategory = null;
      } else {
        this.alertService.addAlert('Category already exists..!!', 'error');
      }
      
    } else {
      this.invalid = true;
    }*/
    this.__HttpService.saveCategory(newCategory).subscribe(
      data => {
        
      },
      error => {
        console.error("Error adding Category!");
        return Observable.throw(error);
      }
    );
  
    this.router.navigate(['/Category'])
    this.getCategories();
  }

  update(category: string, idx: number): void {
    const status = this.__HttpService.updateCategory(category, idx);
    if(status) {
      this.alert.addAlert('Category updated successfully..!!', 'success');
    }
  }

  delete(idx: number): void {
    const status = this.__HttpService.deleteCategory(idx);
    if(status) {
      this.alert.addAlert('Category deleted successfully..!!', 'success');
      this.getCategories();
    }
  }

  getCategories(): void {
    this.categories = new Array<any>();
    this.__HttpService.getCategories().forEach(category => {
      this.categories.push({name: category, editable: false});
    });
  }

  filterCategories(search: string) : void {
    this.categories = new Array<any>();
    this.__HttpService.getCategories().filter(category => {
      return category.toLowerCase().indexOf(search.toLowerCase()) !== -1;
    }).forEach(category => {
      this.categories.push({name: category, editable: false});
    });
  }
  ngOnInit() {
  }

 
}