import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { ViewComponent } from './view/view.component';

import {RouterModule,Routes} from '@angular/router';
import { TrackComponent } from './track/track.component';
import { CreateComponent } from './create/create.component';
import { CategoryComponent } from './category/category.component';

import { HttpService } from './http.service';

import { AlertComponent } from './alert/alert.component';
import { AlertService } from './alert/alert.service';
import { BarChart } from './chart/bar-chart.component';
import { ModalComponent } from './modal/modal.component';
import { WelcomeComponent } from './welcome/welcome.component';

const appRouters:Routes=[
{ path:'View',component:ViewComponent},
{ path:'Category',component:CategoryComponent},
{ path:'Track',component:TrackComponent},
{ path:'Create',component:CreateComponent},
{ path:'Welcome',component:WelcomeComponent},
];

@NgModule({
  declarations: [
    AppComponent,
    ViewComponent,
    TrackComponent,
    CreateComponent,
    CategoryComponent,AlertComponent, ModalComponent,BarChart, WelcomeComponent
  ],
  imports: [BrowserModule,  HttpModule,FormsModule, ReactiveFormsModule,
    HttpClientModule,RouterModule.forRoot(appRouters) ],
  
  providers: [HttpService, AlertService],
  bootstrap: [AppComponent]
})


export class AppModule { }
