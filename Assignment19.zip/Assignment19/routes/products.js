var express = require('express');
var router = express.Router();
var Product = require("../controllers/productController.js");

// Get all products
router.get('/', function(req, res) {
  Product.list(req, res);
});

// Get single product by id
router.get('/show/:id', function(req, res) {
  Product.show(req, res);
});

// Create product
router.get('/create', function(req, res) {
  Product.create(req, res);
});

// Save product
router.post('/save', function(req, res) {
  Product.save(req, res);
});

// Edit product
router.get('/edit/:id', function(req, res) {
  Product.edit(req, res);
});

// Edit update
router.post('/update/:id', function(req, res) {
  Product.update(req, res);
});

// Edit update
router.post('/delete/:id', function(req, res, next) {
  Product.delete(req, res);
});

module.exports = router;
