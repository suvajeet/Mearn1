var express=require('express');
var jwt=require('jsonwebtoken');
const app=express();
app.get('/api',function(req,res)
{
res.json
({
text:'This is my app'
});
});

app.post('/api/login',function(req,res)
{
const user={id:3};
token=jwt.sign({user},'password1');
res.json
({
token:token
});
});

app.listen(3000,function()
{
console.log('App listen on Post:3000');
});